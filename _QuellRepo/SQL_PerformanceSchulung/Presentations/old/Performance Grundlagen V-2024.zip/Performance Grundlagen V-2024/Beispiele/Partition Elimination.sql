use master 
GO 
/*
DROP database if exists Perf_Part_elimination
go 
create database Perf_Part_elimination
go 

USE [Perf_Part_elimination]
GO

create partition function PF (int) as range left for values (1,2,3,4)
go 
create partition scheme PS as partition PF all to ([PRIMARY])
go 

drop table if exists part
create table part
(	id int identity(1,1) not null
,	part int not null
,	key1 int not null
,	attrib varchar(10) null
) on PS(part)
go 


insert into part (part,key1,attrib)
select part,	row_number() over (order by 1/0)%5000000 ,choose(part+1,'a','b','c','d','e','f')
from (select top (5000000)  1 a from sys.all_columns a, sys.all_columns b) a
cross join (select part = 0 union all select 1 /*union all select 2*/ union all select 3 union all select 4 union all select 5) x
go 

create unique clustered index ix on part (key1,part) on PS(part)
go 
*/

USE [Perf_Part_elimination]
GO


select * from part
where key1 = 5
and attrib = 'e'
-- actual partitions accessed  1..5
-- partition count  5


select * from part
where key1 = 5
and attrib = 'e'
and part = 4
-- actual partitions accessed  4
-- partition count  1



select @@version

-- Spielereien mit Threads

set statistics time,io on
declare @a int
select @a = 1
from part
where attrib = 'a'
option (maxdop 16)
-- actual number of rows read -- alle Threads haben was zu tun


-- keine Partition bekannt -> alle Partitionen abarbeiten
declare @a int
select @a = 1
from part
where attrib = 'a'
option (maxdop 16)
-- actual number of rows read -- alle Threads haben was zu tun


-- eine Partition bekannt -> 
declare @a int
select @a = 1
from part
where attrib = 'a'
and part = 0
option (maxdop 16)
-- actual number of rows read -- alle Threads haben was zu tun


