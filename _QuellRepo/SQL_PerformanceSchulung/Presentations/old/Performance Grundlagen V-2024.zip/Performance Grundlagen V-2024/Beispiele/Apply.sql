use master


DROP TABLE IF EXISTS #LeftTable;
CREATE TABLE #LeftTable
(
    Id INT,
    Name NVARCHAR(10)
)
INSERT INTO #LeftTable
(
    Id,
    Name
)
VALUES
(1, 'Red'), (2, 'Green'), (3, 'Blue'), (4, 'Yellow'), (5, 'Purple');
go 

DROP TABLE IF EXISTS #RightTable;
CREATE TABLE #RightTable
(
    Id INT,
    ReferenceId INT,
    Name NVARCHAR(10),
	TagIDErfassung int
)
INSERT INTO #RightTable
(
    Id,
    ReferenceId,
    Name,
	TagIDErfassung
)
VALUES
(1, 1, 'Dog',20231120), (2, 1, 'Cat',20120707), (3, 2, 'Bird',20240229), (4, 4, 'Horse',18090525), (5, 3, 'Bear',18090529), (6, 1, 'Andreas',17671122);
GO

-- CROSS APPLY
SELECT L.Name,
       R.Name
FROM #LeftTable L
    CROSS APPLY
(SELECT Name FROM #RightTable R WHERE R.ReferenceId = L.Id) R;

-- INNER JOIN
SELECT L.Name,
       R.Name
FROM #LeftTable L
    INNER JOIN #RightTable R
        ON R.ReferenceId = L.Id;

-- OUTER APPLY
SELECT L.Name,
       R.Name
FROM #LeftTable L
    OUTER APPLY
(SELECT Name FROM #RightTable R WHERE R.ReferenceId = L.Id) R;

-- LEFT OUTER JOIN
SELECT L.Name,
       R.Name
FROM #LeftTable L
    LEFT OUTER JOIN #RightTable R
        ON R.ReferenceId = L.Id;

-- CROSS APPLY with a Table Expression
SELECT *
FROM #LeftTable L
    CROSS APPLY
(
    SELECT TOP 2
        R.Name
    FROM #RightTable R
    WHERE R.ReferenceId = L.Id
    ORDER BY R.Id DESC
) R;
go 

create or alter function TVF_TagID_to_Date (@TagID int)
returns table as return
	select Datum = convert(date,convert(char(8),@TagID),112)
go 

select * 
from #RightTable
outer apply TVF_TagID_to_Date(TagIDErfassung)
GO 
