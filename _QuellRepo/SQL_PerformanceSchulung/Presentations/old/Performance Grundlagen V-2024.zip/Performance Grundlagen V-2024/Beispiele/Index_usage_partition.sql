use Perf_Part_elimination
go 

--> erstellung in			Beispiele\Partition Elimination.sql


-- wir erinnern uns
/*
	drop table if exists part
	create table part
	(	id int identity(1,1) not null
	,	part int not null
	,	key1 int not null
	,	attrib varchar(10) null
	) on PS(part)
	go 
	create unique clustered index ix on part (key1,part) on PS(part)
*/

set statistics time,io on

select max(key1)
from dbo.part
GO 

-- Trick, damit der Optimizer den Index verwenden kann
select max(x.key1) from ( 
	select distinct partition_number 
	from sys.partitions p 
	where object_id = object_id ('dbo.part') 
) p outer apply ( 
	select max(key1) key1 
	from dbo.part with (nolock) 
	where $partition.[PF](part) = p.partition_number 
) x
go
