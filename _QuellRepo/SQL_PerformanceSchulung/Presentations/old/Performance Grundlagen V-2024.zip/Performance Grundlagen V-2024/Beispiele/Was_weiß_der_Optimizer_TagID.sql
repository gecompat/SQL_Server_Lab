USE master
GO

-- l�schen, wenn bereits vorhanden
DROP DATABASE IF EXISTS Perf_Optimizer_known
CREATE DATABASE Perf_Optimizer_known
GO 
ALTER DATABASE [Perf_Optimizer_known] SET AUTO_CREATE_STATISTICS OFF
GO
ALTER DATABASE [Perf_Optimizer_known] SET AUTO_UPDATE_STATISTICS OFF WITH NO_WAIT
GO


USE Perf_Optimizer_known
GO 
RAISERROR ('-- Tabellen erstellen - tabelleA',0,0) WITH NOWAIT
-- Tabellen erstellen
DROP TABLE IF EXISTS tabelleA
CREATE TABLE tabelleA (
	TagID INT NOT NULL
	,Datum DATE NOT NULL
)
RAISERROR ('-- Tabellen inserten  - tabelleA',0,0) WITH NOWAIT
INSERT INTO tabelleA
SELECT TOP (DATEDIFF(DAY,'0001-01-01','9999-12-31')) CONVERT(INT,CONVERT(CHAR(8),DATEADD(DAY,ROW_NUMBER() OVER (ORDER BY 1/0),CONVERT(DATE,'0001-01-01')),112))
,DATEADD(DAY,ROW_NUMBER() OVER (ORDER BY 1/0),CONVERT(DATE,'0001-01-01'))
FROM sys.objects a, sys.columns b,sys.objects c
GO 

raiserror ('-- Tabellen erstellen - tabelleA',0,0) with nowait
drop table if exists tabelleB
create table tabelleB (
	KeyCol int identity(1,1) not null
	,Datum date not null
	,Attrib varchar(100)
)
raiserror ('-- Tabellen inserten  - tabelleA',0,0) with nowait
insert into tabelleB
select top 1000000
dateadd(day,rand(convert(varbinary(max),newid()))*10000+1,convert(date,'0001-01-01'))
,replicate ('a', 100)
from sys.objects a, sys.columns b,sys.objects c
go 

select 'Anzahl Rows tabelleA', count(*) from tabelleA 
select 'Anzahl Rows tabelleB', count(*) from tabelleB







-- einschalten von Include Actual Execution-Plan CTLR-M
set statistics time,io on
go


select * from tabelleA 






-- kein Index keine Statistik
-- rows read:  3652058
-- estimated: ~1900
UPDATE statistics tabelleA with SAMPLE 0 ROWS -- alle autocreated statistiken l�schen
go
dbcc freeproccache -- sicherstellen, dass neuer Plan erzeugt wird
go
select [a].[TagID],	 [a].[Datum], [b].[KeyCol], [b].[Datum], [b].[Attrib]
from tabelleA a
inner join tabelleB b on a.Datum = b.Datum
where TagID = 00011231
option (maxdop 1) -- keine Pralellverarbeitung f�r BSP
go
select @@version
-- Index auf TagID ->
-- rows read: 1
-- estimated: 1
drop index if exists ix_tagid on tabelleA
create unique index ix_tagid on tabelleA (TagID)
-- mit Index wird implizit eine Statistik auf den IX angelegt
select * from sys.stats where object_id = object_id ('tabelleA')
go 
dbcc freeproccache
go 
select [a].[TagID],	 [a].[Datum], [b].[KeyCol], [b].[Datum], [b].[Attrib]
from tabelleA a
inner join tabelleB b on a.Datum = b.Datum
where TagID = 00011231
option (maxdop 1)
go
drop index if exists ix_tagid on tabelleA
go 


-- Index auf TagID,Datum
-- rows read: 1
-- estimated: 1
drop index if exists ix_tagid_datum on tabelleA
create unique index ix_tagid_datum on tabelleA (TagID,Datum)
go
dbcc freeproccache
go 
select [a].[TagID],	 [a].[Datum], [b].[KeyCol], [b].[Datum], [b].[Attrib]
from tabelleA a
inner join tabelleB b on a.Datum = b.Datum
where TagID = 00011231
option (maxdop 1)
go 
drop index if exists ix_tagid_datum on tabelleA
go 



-- Index auf Datum,TagID
-- rows read:  3652058
-- estimated: ~1900
drop index if exists ix_datum_tagid on tabelleA
create unique index ix_datum_tagid on tabelleA (Datum,TagID)
go
dbcc freeproccache
go
select [a].[TagID],	 [a].[Datum], [b].[KeyCol], [b].[Datum], [b].[Attrib]
from tabelleA a
inner join tabelleB b on a.Datum = b.Datum
where TagID = 00011231
option (maxdop 1)
go 
drop index if exists ix_datum_tagid on tabelleA
go 



-- Index auf Datum
-- rows read:  3652058
-- estimated: ~1900
drop index if exists ix_datum on tabelleA
create unique index ix_datum on tabelleA (Datum)
go
dbcc freeproccache
go
select [a].[TagID],	 [a].[Datum], [b].[KeyCol], [b].[Datum], [b].[Attrib]
from tabelleA a
inner join tabelleB b on a.Datum = b.Datum
where TagID = 00011231
option (maxdop 1)
go
drop index if exists ix_datum on tabelleA
go 

-- Statistiken auf TagID
-- rows read:  3652058
-- estimated:  1
if exists (select * from sys.stats where name = 'stat_tabelleA_TagID') drop statistics tabelleA.stat_tabelleA_TagID
create statistics stat_tabelleA_TagID on tabelleA (TagID) with fullscan
go
dbcc freeproccache
go
select [a].[TagID],	 [a].[Datum], [b].[KeyCol], [b].[Datum], [b].[Attrib]
from tabelleA a
inner join tabelleB b on a.Datum = b.Datum
where TagID = 00011231
option (maxdop 1)
go
drop statistics tabelleA.stat_tabelleA_TagID



-- Statistiken auf TagID
-- rows read:  3652058
-- estimated:  ~1900
drop index if exists ix_CI_tagid on tabelleA
create unique clustered index ix_CI_tagid on tabelleA (Datum,TagID)
go 
-- mit Index wird implizit eine Statistik angelegt
select * from sys.stats where object_id = object_id ('tabelleA')
-- welche Daten stehen drinnen?
select * from sys.dm_db_stats_histogram (object_id ('tabelleA'),1)
-- wie schaut es aus, wenn die Statistiken "alt" (in diesem Fall nicht vorhanden sind)
update statistics tabelleA (ix_CI_tagid) with sample 0 rows
select * from sys.dm_db_stats_histogram (object_id ('tabelleA'),1)
go 
dbcc freeproccache
go
select [a].[TagID],	 [a].[Datum], [b].[KeyCol], [b].[Datum], [b].[Attrib]
from tabelleA a
inner join tabelleB b on a.Datum = b.Datum
where TagID = 00011231
option (maxdop 1)
go
drop index if exists ix_CI_tagid on tabelleA
go
--> Vorhandensein eines Index n�tzt f�r nicht f�r richtigte Sch�tzung! -> die Statistik gibt vor wie viele Daten erwartet werden!

-- saubere Tabellen
alter table tabelleA add constraint PK_tabelleA primary key clustered (TagID)
--> Statistik ist vorhanden - aber mit ganz wenig Histogram Eintr�gen - gen�gt aber, da Cardinalit�t verdeutlicht, dass es jeweils 1 Satz Pro Wert ist
select * from sys.dm_db_stats_histogram (object_id ('tabelleA'),1)
select * from sys.dm_db_stats_properties (object_id ('tabelleA'),1)

-- Primary Key anlegen
alter table tabelleB add constraint PK_tabelleB primary key clustered (KeyCol)
create index IX_tabelleB_Datum on tabelleB (Datum)
go 

dbcc freeproccache
go 
select [a].[TagID],	 [a].[Datum], [b].[KeyCol], [b].[Datum], [b].[Attrib]
from tabelleA a
inner join tabelleB b on a.Datum = b.Datum
where TagID = 00011231
option (maxdop 1)
go 

-- "alte" Statistiken
update statistics tabelleA (PK_tabelleA) with sample 0 rows
update statistics tabelleB (PK_tabelleB) with sample 0 rows
update statistics tabelleB (IX_tabelleB_Datum) with sample 0 rows
go 
dbcc freeproccache
go 
select [a].[TagID],	 [a].[Datum], [b].[KeyCol], [b].[Datum], [b].[Attrib]
from tabelleA a
inner join tabelleB b on a.Datum = b.Datum
where TagID = 00011231
option (maxdop 1)
go 

--> PK liefert weitere Informationen an den QueryOptimizer
-- auch mit falschen Statistiken wei� er, dass es nur 1 Satz in der TabelleA sein kann
-- die TabelleB sch�tz er mit seinen Default Werten 0,1% (in diesem Fall)


-- Schlussfolgerung:  je treffender die Schemadefinitionen sind, umso besser kann der Optimizer den Plan entwickeln


-- use master ; drop database if exists Perf_Optimizer_known