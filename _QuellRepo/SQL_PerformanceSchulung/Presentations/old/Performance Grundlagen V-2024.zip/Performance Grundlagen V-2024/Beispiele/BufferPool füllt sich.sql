-- BufferPool f�llt sich ;-)

-- Task Manager starten - Arbeitsspeicher anzeigen
-- SQL-Server restart
-- dann diese Statements absetzen
SET STATISTICS TIME ON

DECLARE @a INT
SELECT @a = BINARY_CHECKSUM(*) FROM Data.Customer
SELECT @a = BINARY_CHECKSUM(*) from Data.CurrencyExchange
select @a = BINARY_CHECKSUM(*) from Data.Date
select @a = BINARY_CHECKSUM(*) from Data.Product
select @a = BINARY_CHECKSUM(*) from Data.Sales
select @a = BINARY_CHECKSUM(*) from Data.Store
select @a = BINARY_CHECKSUM(*) from Data.Orders
select @a = BINARY_CHECKSUM(*) from Data.OrderRows


dbcc freeproccache
DBCC DROPCLEANBUFFERS

