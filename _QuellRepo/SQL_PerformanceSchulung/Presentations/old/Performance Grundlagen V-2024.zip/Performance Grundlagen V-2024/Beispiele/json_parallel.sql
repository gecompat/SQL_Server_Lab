use PerformanceLab
go 
select count(*)
from PerformanceLab.demo.AccountMaster am
inner join PerformanceLab.demo.AccountDailyValue adv on am.AccountId = adv.AccountId
inner join PerformanceLab.demo.Account a on am.AccountId = a.AccountId
where a.AccountNumber between 10000 and 6077880


DECLARE @json NVARCHAR(2048) = N'{
   "AccountMin": 10000,
   "AccountMax": 6077880
}';


select count(*)
from PerformanceLab.demo.AccountMaster am
inner join PerformanceLab.demo.AccountDailyValue adv on am.AccountId = adv.AccountId
inner join PerformanceLab.demo.Account a on am.AccountId = a.AccountId
where a.AccountNumber between JSON_VALUE(@json,'$.AccountMin') and JSON_VALUE(@json,'$.AccountMax')


go 
declare @j varchar(max)
set @j = (
	select AccountId
	from PerformanceLab.demo.Account a
	where rand(convert(varbinary(20),newid())) >= 0.5
	for json auto
)
print @j
select j.*
from PerformanceLab.demo.AccountMaster am
inner join PerformanceLab.demo.AccountDailyValue adv on am.AccountId = adv.AccountId
inner join PerformanceLab.demo.Account a on am.AccountId = a.AccountId
inner join OpenJson(@j) j on a.AccountNumber = j.[value] and j.[key] = 'AccountId'








