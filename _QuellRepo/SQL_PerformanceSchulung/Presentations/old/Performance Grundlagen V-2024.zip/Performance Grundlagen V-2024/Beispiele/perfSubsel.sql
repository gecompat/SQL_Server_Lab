--drop database if exists Perf_Subselect;
go 
--create database Perf_Subselect;
go
use Perf_Subselect;
go
set statistics time,io off
set nocount on 

/*
-- TestObjekte erstellen
drop table if exists tabA
create table dbo.tabA (ID int identity (1,1) not null
, Key1 int
, Key2 int
, Attrib_num decimal (15,2)
, Attrib_alpha varchar(15)
)
create unique clustered index ix on tabA (ID)
create unique index ix_lk on tabA (Key1,Key2)

drop table if exists tabB
create table dbo.tabB (ID int identity(1,1) not null
, Key1 int
, Key2 int
, Attrib_num decimal (15,2)
, Attrib_alpha varchar(15)
)
create unique clustered index ix on tabB (ID)
create unique index ix_lk on tabB (Key1,Key2)


insert into tabA
select a.value as Key1, b.value as Key2, rand(convert(varbinary(max),newid()))*100 as Attrib_num
, nullif(replicate(iif(convert(int,rand(convert(varbinary(max),newid()))*2)=1
,	char(convert(int,rand(convert(varbinary(max),newid()))*(90-65)+65))
,	char(convert(int,rand(convert(varbinary(max),newid()))*(122-97)+97))
)
+ iif(convert(int,rand(convert(varbinary(max),newid()))*2)=1
,	char(convert(int,rand(convert(varbinary(max),newid()))*(90-65)+65))
,	char(convert(int,rand(convert(varbinary(max),newid()))*(122-97)+97))
),	convert(int,rand(convert(varbinary(max),newid()))*7)
),'') Attrib_alpha
from generate_series(1,10000) a -- 1000
cross join generate_series(1,1000) b -- 10 000 000 bzw. 1Mio

select top 1000 * from tabB



truncate table tabB
insert into tabB
select Key2,Key1,Attrib_num,Attrib_alpha
from tabA
*/


-- wieviele I/O ben�tigt ein Table Scan
print '----------------------------------------------- wie viele Pages haben die Tables'
drop table if exists #a
drop table if exists #b
drop table if exists #c
set statistics io, time on 
select * into #a from tabA			-- 47912 pages
select Key1,Key2 into #b from tabA	-- 22824 pages ix_lk
select * into #c from tabB			-- 47908 pages



-- Ausgangs Select
set statistics time,io on
drop table if exists #first_version
select a.ID, a.Key1, (
			-- ich erzwinge ein nested loop - dadurch, dass abh�ngig von tabA max oder min ben�tigt wird
			select max(b.Attrib_alpha)
			from tabB b
			where a.Key1 = b.Key1--*a.Key1/a.Key1 -- ich erzwinge ein nested loop  -> a.Key1 = b.Key1
			) Attrib_alpha_B
into #first_version
from tabA a
/* 10 Mio
CPU time = 17579 ms,  elapsed time = 2446 ms.
Table 'Worktable'. Scan count 0, logical reads 0, physical reads 0, page server reads 0, read-ahead reads 0, page server read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob page server reads 0, lob read-ahead reads 0, lob page server read-ahead reads 0.
Table 'Workfile'. Scan count 0, logical reads 0, physical reads 0, page server reads 0, read-ahead reads 0, page server read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob page server reads 0, lob read-ahead reads 0, lob page server read-ahead reads 0.
Table 'tabB'. Scan count 9, logical reads 48016, physical reads 0, page server reads 0, read-ahead reads 0, page server read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob page server reads 0, lob read-ahead reads 0, lob page server read-ahead reads 0.
Table 'tabA'. Scan count 9, logical reads 22672, physical reads 0, page server reads 0, read-ahead reads 0, page server read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob page server reads 0, lob read-ahead reads 0, lob page server read-ahead reads 0.

*/

/* Kontrolle, ob mit anderer SQL-Server Compatibility Level anderes Ergebnis
declare @sql nvarchar(max), @comp_lv int = (select compatibility_level from sys.databases where name = 'perf_subsel'), @stmt nvarchar(max) = N'
print ''----------------------------------------------- first_version - compatibility_level: '' + convert(varchar(max),@comp_lv ) 
set statistics time,io on
drop table if exists #first_version
select a.ID, a.Key1, (
			-- ich erzwinge ein nested loop - dadurch, dass abh�ngig von tabA max oder min ben�tigt wird
			select max(b.Attrib_alpha)
			from tabB b
			where a.Key1 = b.Key1--*a.Key1/a.Key1 -- ich erzwinge ein nested loop  -> a.Key1 = b.Key1
			) Attrib_alpha_B
into #first_version
from tabA a
'
while @comp_lv >= 100
begin 
	set statistics time,io off
	set @sql = 'alter database perf_subsel set compatibility_level = ' + convert(varchar(max),@comp_lv )
	exec sp_executesql @sql 
	
	exec sp_executesql @sql = @stmt, @params = N'@comp_lv int', @comp_lv = @comp_lv
	set statistics time,io off
	set @comp_lv -= 10
end 
alter database perf_subsel set compatibility_level = 160
*/


go


-- Logik�nderung und auf einmal langsam
print '----------------------------------------------- auf einmal langsam'
drop table if exists #c 
select a.ID, a.Key1, (
			-- ich erzwinge ein nested loop - dadurch, dass abh�ngig von tabA max oder min ben�tigt wird
			select case when a.Attrib_alpha > 'Z'	then max(b.Attrib_alpha)
													else min(b.Attrib_alpha)
						end 
			from tabB b
			where a.Key1 = b.Key1--*a.Key1/a.Key1 -- ich erzwinge ein nested loop  -> a.Key1 = b.Key1
			) Attrib_alpha_B
into #c
from tabA a

-- Versuch es mit union all zu machen
select a.ID, a.Key1, (
			-- ich erzwinge ein nested loop - dadurch, dass abh�ngig von taba max oder min ben�tigt wird
			select  max(b.Attrib_alpha)
			from tabB b
			where Attrib_alpha > 'z'
			and a.Key1 = b.Key1--*a.key1/a.key1 -- ich erzwinge ein nested loop  -> a.key1 = b.key1
			union all 
			select  min(b.Attrib_alpha)
			from tabB b
			where Attrib_alpha <= 'z'
			and a.Key1 = b.Key1--*a.key1/a.key1 -- ich erzwinge ein nested loop  -> a.key1 = b.key1
			) attrib_alpha_b
into #hugo
from tabA a

/* 10 Mio
CPU time = 52561 ms,  elapsed time = 26363 ms.
Table 'tabA'. Scan count 9, logical reads 47776, physical reads 0, page server reads 0, read-ahead reads 0, page server read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob page server reads 0, lob read-ahead reads 0, lob page server read-ahead reads 0.
Table 'Worktable'. Scan count 10000, logical reads 30179590, physical reads 0, page server reads 0, read-ahead reads 0, page server read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob page server reads 0, lob read-ahead reads 0, lob page server read-ahead reads 0.
Table 'tabB'. Scan count 1, logical reads 47322, physical reads 0, page server reads 0, read-ahead reads 0, page server read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob page server reads 0, lob read-ahead reads 0, lob page server read-ahead reads 0.
Table 'Worktable'. Scan count 0, logical reads 0, physical reads 0, page server reads 0, read-ahead reads 0, page server read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob page server reads 0, lob read-ahead reads 0, lob page server read-ahead reads 0.
*/
go


-- wir sind gescheiter als der Optimizer
print '----------------------------------------------- so geht''s schneller'
drop table if exists #d
select a.ID, a.Key1, Attrib_alpha_B = case when a.Attrib_alpha > 'Z' then max_Attrib_alpha else min_Attrib_alpha end 
into #d
from tabA a
left join (	select Key1, min(Attrib_alpha) min_Attrib_alpha, max(Attrib_alpha) max_Attrib_alpha
			from tabB
			group by Key1
		) b on a.Key1 = b.Key1
/* 10 Mio
CPU time = 20265 ms,  elapsed time = 2619 ms.
Table 'Worktable'. Scan count 0, logical reads 0, physical reads 0, page server reads 0, read-ahead reads 0, page server read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob page server reads 0, lob read-ahead reads 0, lob page server read-ahead reads 0.
Table 'Workfile'. Scan count 0, logical reads 0, physical reads 0, page server reads 0, read-ahead reads 0, page server read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob page server reads 0, lob read-ahead reads 0, lob page server read-ahead reads 0.
Table 'tabB'. Scan count 9, logical reads 48016, physical reads 0, page server reads 0, read-ahead reads 0, page server read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob page server reads 0, lob read-ahead reads 0, lob page server read-ahead reads 0.
Table 'tabA'. Scan count 9, logical reads 47852, physical reads 0, page server reads 0, read-ahead reads 0, page server read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob page server reads 0, lob read-ahead reads 0, lob page server read-ahead reads 0.

*/

set statistics time,io off

-- Kontrolle Ergebnis = gleich
select *
from #c c
full outer join #d d on c.ID = d.ID
where c.ID is null or d.ID is null
or c.Key1 != d.Key1
or c.Attrib_alpha_B != d.Attrib_alpha_B


