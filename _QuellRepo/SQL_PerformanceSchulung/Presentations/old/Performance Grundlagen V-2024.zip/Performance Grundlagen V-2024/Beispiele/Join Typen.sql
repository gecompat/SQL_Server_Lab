use AdventureWorks2022
GO 

/*


select sod.ProductID, count(*)
from Sales.SalesOrderDetail sod
inner join Sales.SalesOrderHeader soh on sod.SalesOrderID = soh.SalesOrderID
group by sod.ProductID
order by 2
*/


-- Nested Loop
select *
from Sales.SalesOrderDetail sod
inner join Sales.SalesOrderHeader soh on sod.SalesOrderID = soh.SalesOrderID
where sod.ProductID = 897


-- Merge Join
select *
from Sales.SalesOrderDetail sod
inner join Sales.SalesOrderHeader soh on sod.SalesOrderID = soh.SalesOrderID


-- Hash Join
SELECT DISTINCT e.JobTitle, d.Name
FROM HumanResources.Employee AS e
JOIN HumanResources.EmployeeDepartmentHistory AS edh
ON e.BusinessEntityID = edh.BusinessEntityID
JOIN HumanResources.Department AS d
ON edh.DepartmentID = d.DepartmentID;



-- Bitmap Hash Join

use ContosoRetailDW
go 

-- actual Execution Plan
-- Achtung mit aktuellem SSMS kein eigenes Icon mehr, sondern steckt in Predicate von Read
--  PROBE([Opt_Bitmapnnnn],source)

SELECT     ds.StoreManager,
           dp.BrandName,
           SUM(fos.TotalCost)
FROM       dbo.FactOnlineSales AS fos
INNER JOIN dbo.DimStore AS ds
      ON   ds.StoreKey = fos.StoreKey
INNER JOIN dbo.DimProduct AS dp
      ON   dp.ProductKey = fos.ProductKey
WHERE      ds.EmployeeCount < 30
AND        dp.ColorName = 'Black'
GROUP BY   ds.StoreManager,
           dp.BrandName
