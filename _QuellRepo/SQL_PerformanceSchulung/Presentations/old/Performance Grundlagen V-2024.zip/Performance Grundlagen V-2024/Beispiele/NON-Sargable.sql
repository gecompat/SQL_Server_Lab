use AdventureWorks2022
GO 

/*
-- Systemkatalog auslesen f�r Info welche Tab geeignet

select s.name, o.name, c.name, t.* from sys.columns c
inner join sys.types t on c.user_type_id = t.user_type_id and c.system_type_id = t.system_type_id
inner join sys.objects o on c.object_id = o.object_id 
inner join sys.schemas s on o.schema_id = s.schema_id
where t.name = 'varchar'

select s.name, o.name, sum(rows)
from sys.partitions p
inner join sys.objects o on p.object_id = o.object_id 
inner join sys.schemas s on o.schema_id = s.schema_id
where index_id = 1
group by s.name, o.name 
order by 3 desc

*/

-- Index f�r Bsp anlegen
create index IX_SalesOrderHeader on Sales.SalesOrderHeader (CreditCardApprovalCode)
go 

-- falscher Datentyp in der Zuweisung
select CreditCardApprovalCode from Sales.SalesOrderHeader
where CreditCardApprovalCode = N'25904Vi70960'
-- number of Reads 31465

select CreditCardApprovalCode from Sales.SalesOrderHeader
where CreditCardApprovalCode = '25904Vi70960'
-- number of Reads 1

-- Index wieder droppen!
drop index if exists IX_SalesOrderHeader on Sales.SalesOrderHeader 


-- komplexe Berechnungen in der Zuweisung
-- hab ich nicht geschafft ein so komplexes Statement zu schaffen, welches er nicht vorher aufl�st :-(

-- Funktion auf eine Spalte
-- index anlegen
create index IX_SalesOrderHeader on Sales.SalesOrderHeader (OrderDate)
go 
select OrderDate from Sales.SalesOrderHeader
where year(OrderDate) = 2011
-- number of Reads 31465

select OrderDate from Sales.SalesOrderHeader
where OrderDate between '2011-01-01 00:00:00.000' and '2011-12-31 23:59:59.999'
-- number of Reads 1692

-- Index wieder droppen!
drop index if exists IX_SalesOrderHeader on Sales.SalesOrderHeader 

select 43659+29825+279

-- Berechnungen auf Spalten
select SalesOrderID, SalesPersonID, CustomerID from Sales.SalesOrderHeader
where SalesOrderID+SalesPersonID+CustomerID = 73763

select SalesOrderID, SalesPersonID, CustomerID from Sales.SalesOrderHeader
where SalesOrderID/2 = 43659/2


-- OR

declare @ProductID			int = 870 -- 770
declare @ReferenceOrderID	int = 53465 -- 58086
select ProductID, ReferenceOrderID
from [Production].[TransactionHistory]
where (@ProductID = ProductID or @ProductID is null)
and (@ReferenceOrderID = ReferenceOrderID or @ReferenceOrderID is null)


declare @ProductID			int = NULL -- 770
declare @ReferenceOrderID	int = 53465 -- 58086
select ProductID, ReferenceOrderID
from [Production].[TransactionHistory]
where (@ProductID = ProductID or @ProductID is null)
and (@ReferenceOrderID = ReferenceOrderID or @ReferenceOrderID is null)

declare @ProductID			int = NULL -- 770
declare @ReferenceOrderID	int = 53465 -- 58086
select ProductID, ReferenceOrderID
from [Production].[TransactionHistory]
where --(@ProductID = ProductID OR 
		@ProductID is NULL
		--)
and (@ReferenceOrderID = ReferenceOrderID ) --OR @ReferenceOrderID is null)

