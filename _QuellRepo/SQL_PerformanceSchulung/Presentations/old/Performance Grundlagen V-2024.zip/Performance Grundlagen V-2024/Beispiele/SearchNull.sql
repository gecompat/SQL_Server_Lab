use master 
drop database if exists Perf_SearchNull
go 
create database Perf_SearchNull
go 

USE [Perf_SearchNull]
GO

drop table if exists dbo.SearchNull

create table dbo.SearchNull
(	ID int identity(1,1) not null 
, Key1 int null
, Attrib1 varchar(5000) null
)
go
ALTER TABLE [dbo].[SearchNull] ADD constraint PK_SearchNull PRIMARY KEY  CLUSTERED 
(
	[ID] ASC
)WITH (Fillfactor = 99, PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Key1] ON [dbo].[SearchNull]
(
	[Key1] ASC
)WITH (fillfactor = 99,PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO


insert into dbo.SearchNull (Key1)
select top 1000 convert(int,rand(convert(varbinary(max),newid()))*100)
from sys.all_objects,sys.all_columns

insert into dbo.SearchNull (Key1)
select top 1000000 101
from sys.all_objects,sys.all_columns

insert into dbo.SearchNull (Key1)
select null

update statistics dbo.SearchNull with fullscan
go 


set statistics time,io on
select * from dbo.SearchNull 
where Key1 is null
--> Index wird auch bei NULL verwendet!!

-- Beispiel f�r mehrfach Index verwenden
select * from dbo.SearchNull
where Key1 is null or Key1 in (1,5)


-- Beispiel 2 Pr�fixe werden gesucht Index Seek
select * from dbo.SearchNull
where Key1 in (1,99)

