use [AdventureWorksDW2022]
GO

DROP TABLE IF EXISTS #a
SELECT * INTO #a FROM (select '<' name union all select '>') a


SELECT name + ','
FROM #a 
FOR XML PATH('')


SELECT (
	select (

		/* hier eigenes select ohne in dieser Form! */
		select name + ',' FROM #a a
		/* eigenes Select ENDE -> aber for xml path folgt noch!!! also nicht zu viel klammern! */

		for xml path (''),type
	)
.value('(./text())[1]','varchar(max)'))


select 'drop table ' + quotename(s.name) + '.' + quotename(o.name) + char(13) + char(10)
from sys.objects o
inner join sys.schemas s on o.schema_id = s.schema_id 
where type = 'U'
and [o].[is_ms_shipped] = 0
order by s.name, o.name
for xml path ('')


select (
	select (

		/* hier eigenes select ohne in dieser Form! */
		select 'drop table ' + quotename(s.name) + '.' + quotename(o.name) + char(13) + char(10)
		from sys.objects o
		inner join sys.schemas s on o.schema_id = s.schema_id 
		where type = 'U'
		and [o].[is_ms_shipped] = 0
		order by s.name, o.name
		/* eigenes Select ENDE -> aber for xml path folgt noch!!! also nicht zu viel klammern! */

		for xml path (''),type
	)
.value('(./text())[1]','varchar(max)'))


