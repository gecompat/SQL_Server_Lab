use master 
GO 
drop database if exists Perf_Part_Views

exec sp_who2 -- kill 57
go 
create database Perf_Part_Views
go 

USE [Perf_Part_Views]
GO

create partition function PF (int) as range left for values (1,2,3,4)
go 
create partition scheme PS as partition PF all to ([PRIMARY])
go 

drop table if exists part
create table part
(	id int identity(1,1) not null
,	part int not null
,	key1 int not null
,	key2 char(1) not null
,	attrib varchar(10) null
) on PS(part)
go 




insert into part (part,key1,key2,attrib)
select part,	row_number() over (order by 1/0)%100000 ,choose(b,'a','b','c','d','e','f'),choose(b,'a','b','c','d','e','f')
from (
	select top (100000)  1 a
	, convert(int,rand(convert(varbinary(max),newid()))*6)+1 b 
	from sys.all_columns a, sys.all_columns b
	) a
cross join (
	select part = 0 union all 
	select 1 union all 
	/*select 2 union all */
	select 3 union all 
	select 4 union all 
	select 5
	) x
go 

create unique clustered index ix on part (key1,key2,part) on PS(part)
go 

select top 1000 [id],  [part], [key1], [key2], [attrib] from part
go 

-- einzelne Tables anlegen

drop table if exists part_a
create table part_a
(	id int /*identity(1,1)*/ not null
,	part int not null
,	key1 int not null
,	key2 char(1) not null
,	attrib varchar(10) null
) on PS(part)
go 

drop table if exists part_b
create table part_b
(	id int /*identity(1,1)*/ not null
,	part int not null
,	key1 int not null
,	key2 char(1) not null
,	attrib varchar(10) null
) 
go 

drop table if exists part_c
create table part_c
(	id int /*identity(1,1)*/ not null
,	part int not null
,	key1 int not null
,	key2 char(1) not null
,	attrib varchar(10) null
) on PS(part)
go 
drop table if exists part_d
create table part_d
(	id int /*identity(1,1)*/ not null
,	part int not null
,	key1 int not null
,	key2 char(1) not null
,	attrib varchar(10) null
) on PS(part)
go 
drop table if exists part_e
create table part_e
(	id int /*identity(1,1)*/ not null
,	part int not null
,	key1 int not null
,	key2 char(1) not null
,	attrib varchar(10) null
) on PS(part)
go 
drop table if exists part_f
create table part_f
(	id int /*identity(1,1)*/ not null
,	part int not null
,	key1 int not null
,	key2 char(1) not null
,	attrib varchar(10) null
) on PS(part)
go 

insert into part_a select [id], [part], [key1], [key2], [attrib] from part where [key2] = 'a'
insert into part_b select [id], [part], [key1], [key2], [attrib] from part where [key2] = 'b'
insert into part_c select [id], [part], [key1], [key2], [attrib] from part where [key2] = 'c'
insert into part_d select [id], [part], [key1], [key2], [attrib] from part where [key2] = 'd'
insert into part_e select [id], [part], [key1], [key2], [attrib] from part where [key2] = 'e'
insert into part_f select [id], [part], [key1], [key2], [attrib] from part where [key2] = 'f'


-- constraint auf die Tabellen
alter table part_a with check add constraint CHK_a check (key2 <= 'a')
alter table part_b with check add constraint CHK_b check (key2 >'a' and key2 <= 'b')
alter table part_c with check add constraint CHK_c check (key2 >'b' and key2 <= 'c')
alter table part_d with check add constraint CHK_d check (key2 >'c' and key2 <= 'd')
alter table part_e with check add constraint CHK_e check (key2 >'d' and key2 <= 'e')
alter table part_f with check add constraint CHK_f check (key2 >= 'e')
go 

alter table part_a add constraint PK_part_a primary key clustered (id,part,key2) on PS(part)
alter table part_b add constraint PK_part_b primary key clustered (id,part,key2) on PS(part)
alter table part_c add constraint PK_part_c primary key clustered (id,part,key2) on PS(part)
alter table part_d add constraint PK_part_d primary key clustered (id,part,key2) on PS(part)
alter table part_e add constraint PK_part_e primary key clustered (id,part,key2) on PS(part)
alter table part_f add constraint PK_part_f primary key clustered (id,part,key2) on PS(part)


drop view if exists part_view
go
create view part_view 
WITH SCHEMABINDING  
as 
select [id],  [part], [key1], [key2], [attrib] from dbo.part_a union all 
select [id],  [part], [key1], [key2], [attrib] from dbo.part_b union all 
select [id],  [part], [key1], [key2], [attrib] from dbo.part_c union all 
select [id],  [part], [key1], [key2], [attrib] from dbo.part_d union all 
select [id],  [part], [key1], [key2], [attrib] from dbo.part_e union all 
select [id],  [part], [key1], [key2], [attrib] from dbo.part_f  
go

-- execution Plan
select [id],  [part], [key1], [key2], [attrib] 
from part_view
where part = 0
and key1 between 50 and 100
								  
select [id],  [part], [key1], [key2], [attrib] 
from part_view
where part = 0
and key1 between 50 and 100
and key2 = 'c'								  
		






--Create the tables and insert the values.  
CREATE TABLE dbo.SUPPLY1 (  
supplyID INT PRIMARY KEY CHECK (supplyID BETWEEN 1 and 150),  
supplier CHAR(50)  
);  
CREATE TABLE dbo.SUPPLY2 (  
supplyID INT PRIMARY KEY CHECK (supplyID BETWEEN 151 and 300),  
supplier CHAR(50)  
);  
CREATE TABLE dbo.SUPPLY3 (  
supplyID INT PRIMARY KEY CHECK (supplyID BETWEEN 301 and 450),  
supplier CHAR(50)  
);  
CREATE TABLE dbo.SUPPLY4 (  
supplyID INT PRIMARY KEY CHECK (supplyID BETWEEN 451 and 600),  
supplier CHAR(50)  
);  
GO  
--Create the view that combines all supplier tables.  
CREATE VIEW dbo.all_supplier_view  
WITH SCHEMABINDING  
AS  
SELECT supplyID, supplier  
  FROM dbo.SUPPLY1  
UNION ALL  
SELECT supplyID, supplier  
  FROM dbo.SUPPLY2  
UNION ALL  
SELECT supplyID, supplier  
  FROM dbo.SUPPLY3  
UNION ALL  
SELECT supplyID, supplier  
  FROM dbo.SUPPLY4;  
GO
INSERT dbo.all_supplier_view VALUES ('1', 'CaliforniaCorp'), ('5', 'BraziliaLtd')    
, ('231', 'FarEast'), ('280', 'NZ')  
, ('321', 'EuroGroup'), ('442', 'UKArchip')  
, ('475', 'India'), ('521', 'Afrique');  
GO

select * from dbo.[SUPPLY1]
select * from dbo.[SUPPLY2]
select * from dbo.[SUPPLY3]
select * from dbo.[SUPPLY4]

