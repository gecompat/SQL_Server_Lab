
-- string_split
SELECT * FROM STRING_SPLIT ('abc|36000|hallo','|')
SELECT * FROM STRING_SPLIT ('abc|36000|hallo','|',1)


-- string_agg
SELECT STRING_AGG (a,'|')
FROM (
	SELECT 1 id, 'abc' a
	UNION ALL SELECT 2,'36000'
	UNION ALL SELECT 2,'hallo'
) a 

SELECT STRING_AGG (a,'|') WITHIN GROUP (ORDER BY a DESC)
FROM (
	SELECT 1 id, 'abc' a
	UNION ALL SELECT 2,'36000'
	UNION ALL SELECT 2,'hallo'
) a 
GROUP BY id


-- trim
SELECT '#' + TRIM(LEADING ' .,0' FROM '000010.001,00  ') + '#'
SELECT '#' + TRIM(TRAILING ' .,0' FROM '000010.001,00  ') + '#'
select '#' + trim(both ' .,0' from '000010.001,00  ') + '#'
-- ACHTUNG
select '#' + trim(both ' .,0' from ' 10,000.00  ') + '#'


-- quotename
select name, quotename(name), quotename(replicate(']',128)) from sys.objects
select quotename('abc','"')
-- ACHTUNG!   maximal 128 Zeichen -> sysname
select quotename(replicate('a',128)), quotename(replicate('a',129))


-- parsename
select parsename('Server.DB.Schema.Object',1)
select parsename('Server.DB.Schema.Object',2)
select parsename('Server.DB.Schema.Object',3)
select parsename('Server.DB.Schema.Object',4)
-- ACHTUNG
select parsename(replicate('a',129),1)


-- stuff
select stuff('abc123defg',4,3,'')



-- generate_series
select * from generate_series(-10,100,2)
select * from generate_series(convert(decimal(5,2),-10.),convert(decimal(5,2),100),convert(decimal(5,2),.2))




-- convert Date Time
select convert(varchar(max),getdate(),101)
select convert(varchar(max),getdate(),102)
select convert(varchar(max),getdate(),104)
select convert(varchar(max),getdate(),107)
select convert(varchar(max),getdate(),109)
select convert(varchar(max),getdate(),112)
select convert(varchar(max),getdate(),121)

select convert(varchar(max),convert(time(7),getdate()),108)
select convert(varchar(max),convert(time(7),getdate()),109)
select convert(varchar(max),convert(time(7),getdate()),121)


-- Datumsermittlungen
declare @ThisDate date; /* datetime�*/set @ThisDate = getdate();select dateadd(dd, datediff(dd, 0, @ThisDate), 0)���� -- Beginning of this day
select dateadd(dd, datediff(dd, 0, @ThisDate) + 1, 0) -- Beginning of next day
select dateadd(dd, datediff(dd, 0, @ThisDate) - 1, 0) -- Beginning of previous day
select dateadd(wk, datediff(wk, 0, @ThisDate), 0)���� -- Beginning of this week (Monday)
select dateadd(wk, datediff(wk, 0, @ThisDate) + 1, 0) -- Beginning of next week (Monday)
select dateadd(wk, datediff(wk, 0, @ThisDate) - 1, 0) -- Beginning of previous week (Monday)select dateadd(mm, datediff(mm, 0, @ThisDate), 0)���� -- Beginning of this monthselect dateadd(mm, datediff(mm, 0, @ThisDate) + 1, 0) -- Beginning of next monthselect dateadd(mm, datediff(mm, 0, @ThisDate) - 1, 0) -- Beginning of previous monthselect dateadd(qq, datediff(qq, 0, @ThisDate), 0)���� -- Beginning of this quarter (Calendar)select dateadd(qq, datediff(qq, 0, @ThisDate) + 1, 0) -- Beginning of next quarter (Calendar)select dateadd(qq, datediff(qq, 0, @ThisDate) - 1, 0) -- Beginning of previous quarter (Calendar)select dateadd(yy, datediff(yy, 0, @ThisDate), 0)���� -- Beginning of this yearselect dateadd(yy, datediff(yy, 0, @ThisDate) + 1, 0) -- Beginning of next yearselect dateadd(yy, datediff(yy, 0, @ThisDate) - 1, 0) -- Beginning of previous year
select eomonth(dateadd(mm, datediff(mm, 0, @ThisDate) - 1, 0)) -- Ending of previous month



-- choose (index 1 basiert)
select choose (a,11,12,13,14,15)
from (
	select top 10 rand(convert(varbinary(20),newid()))*5+1 a
	from sys.all_columns
) a 



-- greatest / least
select greatest (9,22,11,5)
select least (9,22,11,5)


-- binary_checksum
select binary_checksum(*)
from (
				select 1 a, 'bcd' b
	union all	select 2 a, 'bcdjjj' b
) a 



-- $partition
use [Perf_Part_elimination]
go

select $partition.[PF](2)
select $partition.[PF](-2)
select $partition.[PF](55)


use [ContosoRetailDW]
go 


select *
from (
	select * , r = row_number() over (partition by Datekey order by LoadDate asc) 
	from FactStrategyPlan 
) a 
where r = 1



-- CONCAT_WS
select concat_ws('|',1,'abc',null,convert(date,getdate()))
