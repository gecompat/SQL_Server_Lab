use AdventureWorks2022
go

--Tipping Point

select s.name, o.name, sum(rows)
from sys.partitions p
inner join sys.objects o on p.object_id = o.object_id
inner join sys.schemas s on o.schema_id= s.schema_id
WHERE index_id IN (0,1)
group by s.name, o.name
order by 3 desc


-- 2 Selects, die einen vorhandenen IX verwenden
-- lt. Statistik 392 S�tze
select *
from Sales.SalesOrderDetail
where ProductID = 722

-- lt. Statistik 407 S�tze
select *
from Sales.SalesOrderDetail
where ProductID = 882


-- erstes Select macht einen Nested Loop join
-- zweites macht einen Clustered Index Scan

-- irgendwo zwischen diesen Werten ist der Tipping Point, an dem die Kosten f�r Nested Loop h�her sind, als f�r einen Table Scan


