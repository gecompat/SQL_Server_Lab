use master 
GO 
drop database if exists Perf_ParameterSniffing

--exec sp_who2 -- kill 120
go 
create database Perf_ParameterSniffing
go 

USE [Perf_ParameterSniffing]
GO

drop table if exists Employees
CREATE TABLE Employees
  (
   EmpID INT NOT NULL ,
   EmpName VARCHAR(50) NOT NULL ,
   EmpAddress VARCHAR(50) NOT NULL ,
   EmpDEPID int NOT NULL ,
   EmpBirthDay DATETIME ,
   PRIMARY KEY CLUSTERED ( EmpID )
  )
GO

drop table if exists Employee_Department
CREATE TABLE Employee_Department
  (
   DepID INT NOT NULL ,
   DepName VARCHAR(50) NOT NULL ,
   PRIMARY KEY CLUSTERED ( DepID ),
   index Employee_Departent unique nonclustered (DepName)
  )
  GO

drop index Employee_Departent on Employee_Department
 
CREATE INDEX IX_Employees_EmpDEPID 
ON Employees(EmpDEPID)
GO

 
ALTER TABLE [dbo].[Employees]  WITH CHECK ADD  CONSTRAINT [FK_Employees_EmpDep] FOREIGN KEY([EmpDEPID])
REFERENCES [dbo].[Employee_Department] ([DepID])
GO
 
ALTER TABLE [dbo].[Employees] CHECK CONSTRAINT [FK_Employees_EmpDep]
GO





-- BeispielDaten inserten
truncate table Employees
delete from Employee_Department
go 
insert into Employee_Department with (tablock)
select top 1000 row_number() over (order by 1/0) DepID 
, DepName = 'Department ' + convert(varchar(max),row_number() over (order by 1/0))
from sys.[all_columns] a, sys.[all_columns] b

select top 10 * from Employee_Department

truncate table Employees
insert into Employees with (tablock)
select row_number() over (order by 1/0) EmpID 
, EmpName = replicate(substring('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',convert(int,rand(convert(varbinary(max),newid()))*52)+1,1), convert(int,rand(convert(varbinary(max),newid()))*50+1)) 
, EmpAddress = replicate(substring('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',convert(int,rand(convert(varbinary(max),newid()))*52)+1,1), convert(int,rand(convert(varbinary(max),newid()))*46+1)) + ' '
+ replicate(substring('1234567890',convert(int,rand(convert(varbinary(max),newid()))*10)+1,1), convert(int,rand(convert(varbinary(max),newid()))*3+1)) 
, EmpDEPID =	DepID
, EmpBirthDay = convert(date,dateadd(day,convert(int,rand(convert(varbinary(max),newid()))*( datediff(day,'1970-01-01','2010-12-31') )),'1970-01-01'))
-- DepID 1 kommt 1x vor , 2 2x, 3 3x, .... 1000 kommt 1000x vor
from  Employee_Department
cross apply (select top (convert(int,power(DepID/100.,convert(bigint,DepID/166.)))) r= row_number() over (order by 1/0) from sys.[all_columns] a, sys.[all_columns] b, sys.[all_columns] c) x
option (maxdop 16)
go 
update statistics Employees with fullscan
go 



-- Plan Cache leeren
dbcc freeproccache


set statistics time,io on
-- execution plan einschalten

select *
from Employees
where [EmpDEPID] = 1
-- Index Seek mit KeyLookup

select *
from Employees
where [EmpDEPID] = 900
-- Table Scan
go

create or alter proc  Sniffing (@DepID int)
as begin 
	select *
	from Employees
	where [EmpDEPID] = @DepID
end 
go 


SELECT name, value FROM sys.database_scoped_configurations where name= 'PARAMETER_SNIFFING'

USE [master]
GO
ALTER DATABASE [Perf_ParameterSniffing] SET COMPATIBILITY_LEVEL = 150 --SQL SERVER 2019
GO


use [Perf_ParameterSniffing] 
dbcc freeproccache()
exec Sniffing 1
exec Sniffing 900



USE [master]
GO
ALTER DATABASE [Perf_ParameterSniffing] SET COMPATIBILITY_LEVEL = 160 --SQL SERVER 2022
GO

use [Perf_ParameterSniffing] 
dbcc freeproccache()
exec Sniffing 1
exec Sniffing 900
