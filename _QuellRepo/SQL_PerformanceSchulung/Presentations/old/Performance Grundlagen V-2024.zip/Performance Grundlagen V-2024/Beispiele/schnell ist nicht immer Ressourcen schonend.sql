use PerformanceLab
go 


-- schnell ist nicht immer Ressourcen schonend

set statistics time,io on
go
select count(*)
from demo.AccountMaster
where TagIDBis = 99991231
and AccountId between 1000 and 1000000
option (maxdop 64)
-- CPU time = 4795 ms,  elapsed time = 225 ms.
-- Table 'AccountMaster'. Scan count 25, logical reads 215844
-- Table 'Worktable'
go 

select count(*)
from demo.AccountMaster
where TagIDBis = 99991231
and AccountId between 1000 and 1000000
option (maxdop 1)
-- CPU time = 4437 ms,  elapsed time = 4442 ms.
-- Table 'AccountMaster'. Scan count 1, logical reads 211727
go 




-- Wo wird gefiltert?

select ca.AccountId
from demo.AccountMaster am
inner loop join demo.Account a on am.AccountId = a.AccountId
inner loop join demo.CurrentAccount ca on a.AccountId = ca.AccountId
where am.TagIDBis = 99991231
and am.AccountId between 1000 and 1000000
and substring(convert(varchar(max),am.LoadId + isnull(a.BranchId,0) + ca.AccountId)+ '000000',2,4) like '123%'


select a.*
from demo.AccountMaster am
inner loop join demo.Account a on am.AccountId = a.AccountId
where am.TagIDBis = 99991231
and substring(convert(varchar(max),am.AccountId + am.AccountId)+ '000000',2,4) like '123%'
and am.AccountId between 1000 and 1000000



-- Table/Index Scan vs. Index Seek
set statistics time,io on
select count(*)
from demo.AccountMaster
where AccountId % 5 = 4
-- Table 'AccountMaster'. Scan count 9, logical reads 1600567, physical reads 0

select count(*)
from demo.AccountMaster
where AccountId between 100000 and 1000000
-- Table 'AccountMaster'. Scan count 1, logical reads 198120, physical reads 0


