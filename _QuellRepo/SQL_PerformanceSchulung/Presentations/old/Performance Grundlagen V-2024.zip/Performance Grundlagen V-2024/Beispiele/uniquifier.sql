use LRCTPIS01_ZDW
go

-- UNIQUIFIER


-- Create the tables:
-- Create the indexes:
DROP TABLE IF EXISTS #Unique
DROP TABLE IF EXISTS #NonUnique
DROP TABLE IF EXISTS #UniqueWithinNonUnique
CREATE TABLE #Unique (Col1 INT NOT NULL); -- No Uniquifier
CREATE UNIQUE	CLUSTERED INDEX [idx] ON #Unique([Col1] ASC)				WITH (FILLFACTOR = 100);

CREATE TABLE #NonUnique (Col1 INT NOT NULL); -- Uniquifier required
CREATE			CLUSTERED INDEX [idx] ON #NonUnique([Col1] ASC)				WITH (FILLFACTOR = 100);

CREATE TABLE #UniqueWithinNonUnique (Col1 INT NOT NULL); -- Uniquifier available; is it used?
CREATE			CLUSTERED INDEX [idx] ON #UniqueWithinNonUnique([Col1] ASC)	WITH (FILLFACTOR = 100);


-- Populate the tables:
INSERT INTO #Unique ([Col1]) /* unique clustered index */
  SELECT TOP (100000) ROW_NUMBER() OVER (ORDER BY (SELECT 0))	-- eindeutiger Key
  FROM   [master].[sys].[all_columns] sac1
  CROSS JOIN [master].[sys].[all_columns] sac2;

INSERT INTO #NonUnique ([Col1])	/* non unique clustered index */
  SELECT TOP (100000) 999										-- Key Duplicates
  FROM   [master].[sys].[all_columns] sac1
  CROSS JOIN [master].[sys].[all_columns] sac2;

INSERT INTO #UniqueWithinNonUnique ([Col1]) /* non unique clustered index */
  SELECT TOP (100000) ROW_NUMBER() OVER (ORDER BY (SELECT 0))	-- eindeutiger Key
  FROM   [master].[sys].[all_columns] sac1
  CROSS JOIN [master].[sys].[all_columns] sac2;

-- Make sure all data pages are in ideal state:
ALTER INDEX [idx] ON #Unique REBUILD;
ALTER INDEX [idx] ON #NonUnique REBUILD;
ALTER INDEX [idx] ON #UniqueWithinNonUnique REBUILD;


-- Verify inserted data is unique or non-unique as expected:
SELECT TOP (5) * FROM #Unique ORDER BY [Col1] ASC;
SELECT TOP (5) * FROM #NonUnique ORDER BY [Col1] ASC;
SELECT TOP (5) * FROM #UniqueWithinNonUnique ORDER BY [Col1] ASC;


EXEC tempdb.sys.sp_spaceused N'#Unique';
EXEC tempdb.sys.sp_spaceused N'#NonUnique';
EXEC tempdb.sys.sp_spaceused N'#UniqueWithinNonUnique';




DROP TABLE IF EXISTS #DbccResults_Unique
DROP TABLE IF EXISTS #DbccResults_NonUnique
DROP TABLE IF EXISTS #DbccResults_UniqueWithinNonUnique
CREATE TABLE #DbccResults_Unique
(
  [ResultsID]     INT IDENTITY(1, 1) NOT NULL,
  [ParentObject]  NVARCHAR(255),
  [Object]        NVARCHAR(255),
  [Field]         NVARCHAR(255),
  [value]         NVARCHAR(255)
);
CREATE TABLE #DbccResults_NonUnique
(
  [ResultsID]     INT IDENTITY(1, 1) NOT NULL,
  [ParentObject]  NVARCHAR(255),
  [Object]        NVARCHAR(255),
  [Field]         NVARCHAR(255),
  [value]         NVARCHAR(255)
);
CREATE TABLE #DbccResults_UniqueWithinNonUnique
(
  [ResultsID]     INT IDENTITY(1, 1) NOT NULL,
  [ParentObject]  NVARCHAR(255),
  [Object]        NVARCHAR(255),
  [Field]         NVARCHAR(255),
  [value]         NVARCHAR(255)
);


DECLARE @DatabaseID INT = DB_ID(N'tempdb'),
        @FileID INT,
        @PageID INT;
SELECT  @FileID = dpa.allocated_page_file_id,
        @PageID = dpa.allocated_page_page_id
FROM    sys.dm_db_database_page_allocations(@DatabaseID,
          OBJECT_ID(N'tempdb..#Unique'), 1, NULL, 'DETAILED') dpa
WHERE   dpa.[page_type] = 1 -- DATA_PAGE
AND     dpa.[previous_page_page_id] IS NULL; -- first page
INSERT INTO #DbccResults_Unique ([ParentObject], [Object], [Field],
                                 [value])
  EXEC sp_executesql
    N'DBCC PAGE (@DatabaseID, @FileID, @PageID, 3) WITH TABLERESULTS;',
    N'@DatabaseID INT, @FileID INT, @PageID INT',
    @DatabaseID = @DatabaseID, @FileID = @FileID,
    @PageID = @PageID;
---
SELECT  @FileID = dpa.allocated_page_file_id,
        @PageID = dpa.allocated_page_page_id
FROM    sys.dm_db_database_page_allocations(@DatabaseID,
          OBJECT_ID(N'tempdb..#NonUnique'), 1, NULL, 'DETAILED') dpa
WHERE   dpa.[page_type] = 1 -- DATA_PAGE
AND     dpa.[previous_page_page_id] IS NULL; -- first page
INSERT INTO #DbccResults_NonUnique ([ParentObject], [Object], [Field],
                                    [value])
  EXEC sp_executesql
    N'DBCC PAGE (@DatabaseID, @FileID, @PageID, 3) WITH TABLERESULTS;',
    N'@DatabaseID INT, @FileID INT, @PageID INT',
    @DatabaseID = @DatabaseID, @FileID = @FileID, @PageID = @PageID;
---
SELECT  @FileID = dpa.allocated_page_file_id,
        @PageID = dpa.allocated_page_page_id
FROM    sys.dm_db_database_page_allocations(@DatabaseID,
 OBJECT_ID(N'tempdb..#UniqueWithinNonUnique'), 1, NULL, 'DETAILED') dpa
WHERE   dpa.[page_type] = 1 -- DATA_PAGE
AND     dpa.[previous_page_page_id] IS NULL; -- first page
INSERT INTO #DbccResults_UniqueWithinNonUnique ([ParentObject],
                        [Object], [Field], [value])
  EXEC sp_executesql
    N'DBCC PAGE (@DatabaseID, @FileID, @PageID, 3) WITH TABLERESULTS;',
    N'@DatabaseID INT, @FileID INT, @PageID INT',
    @DatabaseID = @DatabaseID, @FileID = @FileID, @PageID = @PageID;

SELECT * FROM #DbccResults_UniqueWithinNonUnique

SELECT N'Unique' AS [Table],
       MAX(CASE WHEN [Field] = N'm_slotCnt' THEN [value] ELSE 0 END)
          AS [RowsOnPage],
       SUM(CASE WHEN [Field] = N'Record Size' AND [value] = 11 THEN 1
          ELSE 0 END) AS [11ByteRow],
       SUM(CASE WHEN [Field] = N'Record Size' AND [value] = 19 THEN 1
          ELSE 0 END) AS [19ByteRow],
       SUM(CASE WHEN [Field] = N'UNIQUIFIER' AND [Object] LIKE
          N'%(physical) 0' THEN 1 ELSE 0 END) AS [UniquifierAvailable],
       SUM(CASE WHEN [Field] = N'UNIQUIFIER' AND [Object] LIKE
          N'%(physical) 4' THEN 1 ELSE 0 END) AS [UniquifierInUse]
FROM   #DbccResults_Unique;
SELECT N'NonUnique' AS [Table],
       MAX(CASE WHEN [Field] = N'm_slotCnt' THEN [value] ELSE 0 END)
          AS [RowsOnPage],
       SUM(CASE WHEN [Field] = N'Record Size' AND [value] = 11 THEN 1
          ELSE 0 END) AS [11ByteRow],
       SUM(CASE WHEN [Field] = N'Record Size' AND [value] = 19 THEN 1
          ELSE 0 END) AS [19ByteRow],
       SUM(CASE WHEN [Field] = N'UNIQUIFIER' AND [Object] LIKE
          N'%(physical) 0' THEN 1 ELSE 0 END) AS [UniquifierAvailable],
       SUM(CASE WHEN [Field] = N'UNIQUIFIER' AND [Object] LIKE
          N'%(physical) 4' THEN 1 ELSE 0 END) AS [UniquifierInUse]
FROM   #DbccResults_NonUnique;
SELECT N'UniqueWithinNonUnique' AS [Table],
       MAX(CASE WHEN [Field] = N'm_slotCnt' THEN [value] ELSE 0 END)
          AS [RowsOnPage],
       SUM(CASE WHEN [Field] = N'Record Size' AND [value] = 11 THEN 1
          ELSE 0 END) AS [11ByteRow],
       SUM(CASE WHEN [Field] = N'Record Size' AND [value] = 19 THEN 1
          ELSE 0 END) AS [19ByteRow],
       SUM(CASE WHEN [Field] = N'UNIQUIFIER' AND [Object] LIKE
          N'%(physical) 0' THEN 1 ELSE 0 END) AS [UniquifierAvailable],
       SUM(CASE WHEN [Field] = N'UNIQUIFIER' AND [Object] LIKE
          N'%(physical) 4' THEN 1 ELSE 0 END) AS [UniquifierInUse]
FROM   #DbccResults_UniqueWithinNonUnique;
go





-- Beispiel, dass Uniquifier hinaufgez�hlt wird
DROP TABLE IF EXISTS #Ueberlauf
CREATE TABLE #Ueberlauf (
id BIGINT NOT NULL
,key_val tinyint
)
CREATE CLUSTERED INDEX ix ON #Ueberlauf (key_val) WITH (FILLFACTOR = 100);
CREATE UNIQUE INDEX ix_u ON #Ueberlauf (id) WITH (FILLFACTOR = 100);


INSERT #Ueberlauf
SELECT 0,1
;
SELECT 'nach insert',* FROM #Ueberlauf

DROP TABLE IF EXISTS #DbccResults_�berlauf
CREATE TABLE #DbccResults_�berlauf
( 
  [ResultsID]     INT IDENTITY(1, 1) NOT NULL,
  [ParentObject]  NVARCHAR(255),
  [Object]        NVARCHAR(255),
  [Field]         NVARCHAR(255),
  [value]         NVARCHAR(255)
);
DECLARE @DatabaseID INT = DB_ID('tempdb'),
        @FileID INT,
        @PageID INT;
SELECT  @FileID = dpa.allocated_page_file_id,
        @PageID = dpa.allocated_page_page_id
FROM    sys.dm_db_database_page_allocations(@DatabaseID,
          OBJECT_ID(N'tempdb..#Ueberlauf'), 1, NULL, 'DETAILED') dpa
WHERE   dpa.[page_type] = 1 -- DATA_PAGE
AND     (	dpa.[previous_page_page_id] IS NULL -- first page
		--OR	dpa.[next_page_page_id] IS NULL -- last page
        )
RAISERROR (' @FileID = %d, @PageID = %d',0,0,@FileID, @PageID) WITH NOWAIT 
INSERT INTO #DbccResults_�berlauf ([ParentObject], [Object], [Field],
                                 [value])
  EXEC sp_executesql
    N'DBCC PAGE (@DatabaseID, @FileID, @PageID, 3) WITH TABLERESULTS;',
    N'@DatabaseID INT, @FileID INT, @PageID INT',
    @DatabaseID = @DatabaseID, @FileID = @FileID,
    @PageID = @PageID;

SELECT * FROM [#DbccResults_�berlauf] WHERE Field = 'UNIQUIFIER'
GO 

-- insert noch ein Satz - erstes Duplicate!
SELECT 'vor insert', * from #Ueberlauf
INSERT #Ueberlauf
SELECT 1,1
;
SELECT 'nach insert',* FROM #Ueberlauf

TRUNCATE TABLE #DbccResults_�berlauf
DECLARE @DatabaseID INT = DB_ID('tempdb'),
        @FileID INT,
        @PageID INT;
SELECT  @FileID = dpa.allocated_page_file_id,
        @PageID = dpa.allocated_page_page_id
FROM    sys.dm_db_database_page_allocations(@DatabaseID,
          OBJECT_ID(N'tempdb..#Ueberlauf'), 1, NULL, 'DETAILED') dpa
WHERE   dpa.[page_type] = 1 -- DATA_PAGE
AND     (	dpa.[previous_page_page_id] IS NULL -- first page
		--OR	dpa.[next_page_page_id] IS NULL -- last page
        )
RAISERROR (' @FileID = %d, @PageID = %d',0,0,@FileID, @PageID) WITH NOWAIT 
INSERT INTO #DbccResults_�berlauf ([ParentObject], [Object], [Field],
                                 [value])
  EXEC sp_executesql
    N'DBCC PAGE (@DatabaseID, @FileID, @PageID, 3) WITH TABLERESULTS;',
    N'@DatabaseID INT, @FileID INT, @PageID INT',
    @DatabaseID = @DatabaseID, @FileID = @FileID,
    @PageID = @PageID;

SELECT * FROM [#DbccResults_�berlauf] WHERE Field = 'UNIQUIFIER'
GO 
-- insert noch ein Satz - zweites Duplicate!
SELECT 'vor insert', * from #Ueberlauf
INSERT #Ueberlauf
SELECT 2,1
;
SELECT 'nach insert',* from #Ueberlauf

TRUNCATE TABLE #DbccResults_�berlauf
DECLARE @DatabaseID INT = DB_ID('tempdb'),
        @FileID INT,
        @PageID INT;
SELECT  @FileID = dpa.allocated_page_file_id,
        @PageID = dpa.allocated_page_page_id
FROM    sys.dm_db_database_page_allocations(@DatabaseID,
          OBJECT_ID(N'tempdb..#Ueberlauf'), 1, NULL, 'DETAILED') dpa
WHERE   dpa.[page_type] = 1 -- DATA_PAGE
AND     (	dpa.[previous_page_page_id] IS NULL -- first page
		--OR	dpa.[next_page_page_id] IS NULL -- last page
        )
RAISERROR (' @FileID = %d, @PageID = %d',0,0,@FileID, @PageID) WITH NOWAIT 
INSERT INTO #DbccResults_�berlauf ([ParentObject], [Object], [Field],
                                 [value])
  EXEC sp_executesql
    N'DBCC PAGE (@DatabaseID, @FileID, @PageID, 3) WITH TABLERESULTS;',
    N'@DatabaseID INT, @FileID INT, @PageID INT',
    @DatabaseID = @DatabaseID, @FileID = @FileID,
    @PageID = @PageID;

SELECT * FROM [#DbccResults_�berlauf] WHERE Field = 'UNIQUIFIER'
GO 


-- auch wenn UNIQUIFIER vorne "frei" sind, wird einfach hinauf gez�hlt!
DELETE #Ueberlauf WHERE id < 2
-- insert noch ein Satz - drittes Duplicate!
SELECT 'vor insert', * from #Ueberlauf
INSERT #Ueberlauf
SELECT 3,1
;
SELECT 'nach insert',* from #Ueberlauf

TRUNCATE TABLE #DbccResults_�berlauf
DECLARE @DatabaseID INT = DB_ID('tempdb'),
        @FileID INT,
        @PageID INT;
SELECT  @FileID = dpa.allocated_page_file_id,
        @PageID = dpa.allocated_page_page_id
FROM    sys.dm_db_database_page_allocations(@DatabaseID,
          OBJECT_ID(N'tempdb..#Ueberlauf'), 1, NULL, 'DETAILED') dpa
WHERE   dpa.[page_type] = 1 -- DATA_PAGE
AND     (	dpa.[previous_page_page_id] IS NULL -- first page
		--OR	dpa.[next_page_page_id] IS NULL -- last page
        )
RAISERROR (' @FileID = %d, @PageID = %d',0,0,@FileID, @PageID) WITH NOWAIT 
INSERT INTO #DbccResults_�berlauf ([ParentObject], [Object], [Field],
                                 [value])
  EXEC sp_executesql
    N'DBCC PAGE (@DatabaseID, @FileID, @PageID, 3) WITH TABLERESULTS;',
    N'@DatabaseID INT, @FileID INT, @PageID INT',
    @DatabaseID = @DatabaseID, @FileID = @FileID,
    @PageID = @PageID;

SELECT * FROM [#DbccResults_�berlauf] WHERE Field = 'UNIQUIFIER'
GO 


-- es wird auf max(UNIQUEFIER) hinauf gez�hlt 
DELETE #Ueberlauf WHERE id = 3  -- aktueller Satz mit max(UNIQUEFIER)
SELECT 'vor insert', * from #Ueberlauf
-- insert noch ein Satz - drittes Duplicate!
INSERT #Ueberlauf
SELECT 3,1
;
SELECT 'nach insert',* from #Ueberlauf

TRUNCATE TABLE #DbccResults_�berlauf
DECLARE @DatabaseID INT = DB_ID('tempdb'),
        @FileID INT,
        @PageID INT;
SELECT  @FileID = dpa.allocated_page_file_id,
        @PageID = dpa.allocated_page_page_id
FROM    sys.dm_db_database_page_allocations(@DatabaseID,
          OBJECT_ID(N'tempdb..#Ueberlauf'), 1, NULL, 'DETAILED') dpa
WHERE   dpa.[page_type] = 1 -- DATA_PAGE
AND     (	dpa.[previous_page_page_id] IS NULL -- first page
		--OR	dpa.[next_page_page_id] IS NULL -- last page
        )
RAISERROR (' @FileID = %d, @PageID = %d',0,0,@FileID, @PageID) WITH NOWAIT 
INSERT INTO #DbccResults_�berlauf ([ParentObject], [Object], [Field],
                                 [value])
  EXEC sp_executesql
    N'DBCC PAGE (@DatabaseID, @FileID, @PageID, 3) WITH TABLERESULTS;',
    N'@DatabaseID INT, @FileID INT, @PageID INT',
    @DatabaseID = @DatabaseID, @FileID = @FileID,
    @PageID = @PageID;

SELECT * FROM [#DbccResults_�berlauf] WHERE Field = 'UNIQUIFIER'
GO 



-- Beispiel, wenn Uniquifier �berl�uft
-- Int kann maximal 2147483647 werden
/* vorbereitet: 

use [Perf_BitmapHASH]
go

--DROP TABLE IF EXISTS dbo.Ueberlauf
CREATE TABLE dbo.Ueberlauf (
id BIGINT NOT NULL
,key_val tinyint
)
CREATE CLUSTERED INDEX ix ON dbo.Ueberlauf (key_val) WITH (FILLFACTOR = 100);
CREATE UNIQUE INDEX ix_u ON dbo.Ueberlauf (id) WITH (FILLFACTOR = 100);
INSERT INTO dbo.Ueberlauf
SELECT 1,1


SET NOCOUNT on
DECLARE @cnt BIGINT, @top BIGINT, @cmt_rate BIGINT = 100000000
SET @cnt = (SELECT MAX(id) FROM dbo.Ueberlauf)
WHILE (1=1)
BEGIN 
	SET @top = IIF(2147483645-@cnt < @cmt_rate,2147483645-@cnt,@cmt_rate)-1
	RAISERROR ('F�ge %I64d S�tze > %I64d ein',0,0,@top,@cnt) WITH NOWAIT 

	INSERT INTO dbo.Ueberlauf
	SELECT TOP (@top) value,1
	FROM GENERATE_SERIES(@cnt+1,CONVERT(BIGINT,2147483645)) -- maximal int Bereich
	ORDER BY value
	--
	-- l�schen der S�tze bis auf letzten Satz
	DELETE FROM dbo.Ueberlauf WHERE id < (@cnt+@top-1)

	IF @top < @cmt_rate BREAK;

	SET @cnt = @cnt + @top

END 
*/



TRUNCATE TABLE #DbccResults_�berlauf
DECLARE @DatabaseID INT = DB_ID(),
        @FileID INT,
        @PageID INT;
SELECT  @FileID = dpa.allocated_page_file_id,
        @PageID = dpa.allocated_page_page_id
FROM    sys.dm_db_database_page_allocations(@DatabaseID,
          OBJECT_ID(N'dbo.Ueberlauf'), 1, NULL, 'DETAILED') dpa
WHERE   dpa.[page_type] = 1 -- DATA_PAGE
AND     (	dpa.[next_page_page_id] IS NULL -- last page
        )
RAISERROR (' @FileID = %d, @PageID = %d',0,0,@FileID, @PageID) WITH NOWAIT 
INSERT INTO #DbccResults_�berlauf ([ParentObject], [Object], [Field],
                                 [value])
  EXEC sp_executesql
    N'DBCC PAGE (@DatabaseID, @FileID, @PageID, 3) WITH TABLERESULTS;',
    N'@DatabaseID INT, @FileID INT, @PageID INT',
    @DatabaseID = @DatabaseID, @FileID = @FileID,
    @PageID = @PageID;

SELECT * FROM [#DbccResults_�berlauf] WHERE Field = 'UNIQUIFIER'
SELECT * FROM dbo.Ueberlauf 


-- Error
BEGIN tran

IF @@trancount > 0
INSERT INTO dbo.Ueberlauf
SELECT MAX(id)+1,1
FROM dbo.Ueberlauf

