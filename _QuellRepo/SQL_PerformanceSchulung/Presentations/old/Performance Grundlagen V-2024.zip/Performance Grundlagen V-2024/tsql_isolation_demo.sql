-- SQL Server Isolation Level Demo
-- Szenario 1: READ COMMITTED Blockierung
-- Öffne zwei Sessions:
-- Session A:
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
BEGIN TRAN;
UPDATE dbo.TestTable SET Wert = 'A' WHERE ID = 1;
-- Halte die Transaktion offen (nicht committen)

-- Session B:
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
SELECT * FROM dbo.TestTable WHERE ID = 1;
-- Blockiert, bis Session A COMMIT oder ROLLBACK ausführt

------------------------------------------------------------
-- Szenario 2: SNAPSHOT Isolation Konflikt (Fehler 3960)
-- Voraussetzung: ALTER DATABASE <DB> SET ALLOW_SNAPSHOT_ISOLATION ON;
-- Session A:
SET TRANSACTION ISOLATION LEVEL SNAPSHOT;
BEGIN TRAN;
SELECT * FROM dbo.TestTable WHERE ID = 1;
UPDATE dbo.TestTable SET Wert = 'A' WHERE ID = 1;
-- Noch nicht committen

-- Session B:
SET TRANSACTION ISOLATION LEVEL SNAPSHOT;
BEGIN TRAN;
SELECT * FROM dbo.TestTable WHERE ID = 1;
UPDATE dbo.TestTable SET Wert = 'B' WHERE ID = 1;
COMMIT;
-- Wenn Session A jetzt COMMIT ausführt -> Fehler 3960 (Update-Konflikt)

------------------------------------------------------------
-- Szenario 3: SERIALIZABLE Range Lock
-- Session A:
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
BEGIN TRAN;
SELECT * FROM dbo.TestTable WHERE ID BETWEEN 1 AND 10;
-- Hält Range Locks bis Transaktionsende

-- Session B:
INSERT INTO dbo.TestTable(ID, Wert) VALUES(5, 'X');
-- Blockiert, bis Session A COMMIT oder ROLLBACK ausführt
